function I_out = increase_brightness(I_in)
AInv = imcomplement(I_in);
BInv = imreducehaze(AInv,'ContrastEnhancement','boost');
BInv = imreducehaze(AInv,0.5,'method','approxdcp');
B = imcomplement(BInv);
I_out = B;
end