function I_out = reduce_brightness(I_in)
I_hist = histeq(I_in);
I_in = double(I_in);
a = min(min(I_in));
b = max(max(I_in));
t = 150;
[m1,m2]=size(I_in);
I_hist=zeros(m1,m2);

for i=1:m1
 for j=1:m2
  I_hist(i,j)=(t/(b-a)).*(I_in(i,j)-a);
 end
end

I_hist=uint8(I_hist);
I_out = I_hist;
end


% I2 = histeq(I);
% imshow(I2) %contrast enhancing
% I=double(I);
% a=min(min(I));
% b=max(max(I));
% t=150;
% [m1,m2]=size(I);
% I2=zeros(m1,m2);
% for i=1:m1
%  for j=1:m2
%   I2(i,j)=(t/(b-a))*(I(i,j)-a);
%  end
% end
% I2=uint8(I2);
% imshow(I2);