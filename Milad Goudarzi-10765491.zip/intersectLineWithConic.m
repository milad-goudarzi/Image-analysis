function [r] = intersectLineWithConic(Line_Coeffs,Conic_Coeffs)

syms x, syms y;

a1 = Line_Coeffs(1);
b1 = Line_Coeffs(2);
c1 = Line_Coeffs(3);
A1 = Conic_Coeffs(1);
B1 = Conic_Coeffs(2);
C1 = Conic_Coeffs(3);
D1 = Conic_Coeffs(4);
E1 = Conic_Coeffs(5);
F1 = Conic_Coeffs(6);

eqn1 = a1*x +b1*y + c1;
eqn2 = A1*x^2 + B1*x*y + C1*y^2 + D1*x + E1*y + F1;

eqns = [eqn1, eqn2];
sol = solve(eqns);

r = [double(sol.x), double(sol.y)];

end
