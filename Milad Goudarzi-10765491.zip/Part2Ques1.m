clc;clear;close all;
rawImage = imread("image 1.jpg");
%% Homework Part 2 first question
% Extracting edges, lines and ellipses authomatically without manual
% intervention.
% All the modifications applied to the image help the edge detection
% technique to find edges more robustly.

% Increasing raw image brightness 
brighter_image = increase_brightness(rawImage);
figure;
imshow(brighter_image);
title("Brighness Increased Image")
hold on;
%%
% converting to a grayscale image
gryscl_img = rgb2gray(brighter_image);

% resizing the image
scale_k = 10;
resized_gryscl_img = imresize(gryscl_img,1/scale_k);

% adjusting the image
adjusted_resized_gryscl_img = imadjust(resized_gryscl_img);
figure;
imshow(adjusted_resized_gryscl_img);
title("Adjusted GrayScale")
%% Applying the edge detection technique
edge_detected = edge(adjusted_resized_gryscl_img,'Canny');

figure;
imshow(edge_detected);
title("Canny Edges");

