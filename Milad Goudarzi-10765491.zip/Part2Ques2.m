clc;clear; close all;
rawImage = imread("image 1.jpg");

maxw = length(rawImage) * 1.5; % will be used to draw lines over the span of the image

% Brightening up the image to see the vase clearer (helps with more robust
% manual points selection)
brighter_image = increase_brightness(rawImage); 

%%
figure;
imshow(brighter_image);
title("Select 5 points on upper cross section")
hold on;

% We introduce (at least) 5 points to form a conic
[x, y]=getpts;

A=[x.^2 x.*y y.^2 x y ones(size(x))]; % conic formula

% To find out the parameters of our conic, we need to find the right null
% space of A. A will be nX6 where n is the number of points we selected in
% previous step.
N = null(A);

cc = N(:, 1);
% changing variables names
[a, b, c, d, e, f] = deal(cc(1),cc(2),cc(3),cc(4),cc(5),cc(6));

% conic matrix
C1=[a b/2 d/2; b/2 c e/2; d/2 e/2 f];

[rows, columns, ~] = size(brighter_image);
im_conic_upper = zeros(rows, columns);

% Computing the incidence relation
for i=1:rows
    for j=1:columns
         im_conic_upper(i,j)=[j i 1]*C1*[j i 1]'; % this is an algebraic error
    end
end

% making pixels greater than zero white and others black
im_conic_upper = im_conic_upper > 0;
% inverting black and white for the regionprops function to work correctly
im_conic_upper_inverted = im_conic_upper < 1;

figure;
imshow(im_conic_upper);

% Calculating the center and from that the minor and major axis of the cones C1 and
% C2 (will be used later)
center = regionprops(im_conic_upper_inverted, 'Centroid');
orient = regionprops(im_conic_upper_inverted, 'Orientation');
min_maj = regionprops(im_conic_upper_inverted, 'MinorAxisLength', 'MajorAxisLength');

X_minor = center.Centroid(1) + [1 -1]*min_maj.MinorAxisLength*sind(orient.Orientation)/2;
Y_minor = center.Centroid(2) + [1 -1]*min_maj.MinorAxisLength*cosd(orient.Orientation)/2;

X_major = center.Centroid(1) + [1 -1]*min_maj.MajorAxisLength*cosd(orient.Orientation)/2;
Y_major = center.Centroid(2) + [-1 1]*min_maj.MajorAxisLength*sind(orient.Orientation)/2;

color = 'r--'; width = 1;
majorLinePoints = [X_major(1) Y_major(1) 1; X_major(2) Y_major(2) 1];
major_line_coeffs_c1 = null(majorLinePoints);
plotLine(major_line_coeffs_c1, [0 maxw], color, width);


color = 'r--'; width = 1;
minorLinePoints = [X_minor(1) Y_minor(1) 1; X_minor(2) Y_minor(2) 1];
minor_line_coeffs_c1 = null(minorLinePoints);
plotLine(minor_line_coeffs_c1, [0 maxw], color, width);

hold on;
line(X_minor, Y_minor);
line(X_major, Y_major);

% imshow(imfuse(im_conic_upper, brighter_image, 'blend'));
hold on;
scatter(x,y, 20, 'filled');

%% lower conic (c2) selection
figure;
imshow(brighter_image);
title("Select 5 points on lower cross section")
hold on;

[x, y]=getpts;

A=[x.^2 x.*y y.^2 x y ones(size(x))];

% same as above
N = null(A);

cc = N(:, 1);
[a, b, c, d, e, f] = deal(cc(1),cc(2),cc(3),cc(4),cc(5),cc(6));

% Matrix of the conic
C2=[a b/2 d/2; b/2 c e/2; d/2 e/2 f];

[rows, columns, ~] = size(brighter_image);
im_conic_lower = zeros(rows, columns);

for i=1:rows
    for j=1:columns
         im_conic_lower(i,j)=[j i 1]*C2*[j i 1]';
    end
end
im_conic_lower = im_conic_lower > 0;
im_conic_lower_inverted = im_conic_lower < 1;

figure;
imshow(im_conic_lower);
center = regionprops(im_conic_lower_inverted, 'Centroid');
orient = regionprops(im_conic_lower_inverted, 'Orientation');
min_maj = regionprops(im_conic_lower_inverted, 'MinorAxisLength', 'MajorAxisLength');

X_minor = center.Centroid(1) + [1 -1]*min_maj.MinorAxisLength*sind(orient.Orientation)/2;
Y_minor = center.Centroid(2) + [1 -1]*min_maj.MinorAxisLength*cosd(orient.Orientation)/2;

X_major = center.Centroid(1) + [1 -1]*min_maj.MajorAxisLength*cosd(orient.Orientation)/2;
Y_major = center.Centroid(2) + [-1 1]*min_maj.MajorAxisLength*sind(orient.Orientation)/2;

color = 'r--'; width = 1;
majorLinePoints = [X_major(1) Y_major(1) 1; X_major(2) Y_major(2) 1];
major_line_coeffs_c2 = null(majorLinePoints);
plotLine(major_line_coeffs_c2, [0 maxw], color, width);


color = 'r--'; width = 1;
minorLinePoints = [X_minor(1) Y_minor(1) 1; X_minor(2) Y_minor(2) 1];
minor_line_coeffs_c2 = null(minorLinePoints);
plotLine(minor_line_coeffs_c2, [0 maxw], color, width);

hold on;
line(X_minor, Y_minor);
line(X_major, Y_major);

%% First method to find the horizon line: from image of the circular points

% intersecting two conics C1 and C2 to get the image of circular points II
% and JJ
Sols = intersectsconics(conicCoeffFromMatrix(C1), conicCoeffFromMatrix(C2));
s1 = [double(Sols(1,1));double(Sols(1,2));1];
s2 = [double(Sols(2,1));double(Sols(2,2));1];
s3 = [double(Sols(3,1));double(Sols(3,2));1];
s4 = [double(Sols(4,1));double(Sols(4,2));1];

II = s3;
JJ = s4;

% the line at the infinity passing through Images of I and J
IJ = [II'; JJ'];
line_IJ = null(IJ);


%% Second method to find the horizon line: finding 2 vanishing points

% Finding l1 and l2:
% calculating duals of c1 and c2 to have the tangent lines as their
% intersection (two of these tangent lines are l1 and l2)
dual_c1 = conicCoeffFromMatrix(inv(C1));
dual_c2 = conicCoeffFromMatrix(inv(C2));

% intersecting duals of c1 and c2
tangent_lines = intersectsconics(dual_c1,dual_c2);
figure(); imshow(brighter_image);

% plotting the tangent lines
color = 'k--'; width = 1;

for k=1:length(tangent_lines)
    line(k,:) = [tangent_lines(k,:), 1];
    plotLine(line(k,:),[0 maxw], color, width);
end
clear line; clear col_array; clear width; clear k;

% intersecting each pair of tangent line to find the one corresponding to
% l1 and l2 intersection
inter_lines(1,:) = intersectlines([tangent_lines(1,:), 1], [tangent_lines(2,:), 1]);
inter_lines(2,:) = intersectlines([tangent_lines(1,:), 1], [tangent_lines(3,:), 1]);
inter_lines(3,:) = intersectlines([tangent_lines(1,:), 1], [tangent_lines(4,:), 1]);
inter_lines(4,:) = intersectlines([tangent_lines(2,:), 1], [tangent_lines(3,:), 1]);
inter_lines(5,:) = intersectlines([tangent_lines(2,:), 1], [tangent_lines(4,:), 1]);
inter_lines(6,:) = intersectlines([tangent_lines(3,:), 1], [tangent_lines(4,:), 1]);

% sorting inter_lines based on its y coords, because the intersection point
% that we want is the one with the highest y coordinate.
[~, I] = sort(inter_lines, 1);
inter_lines_sortedY_asc = inter_lines(I(:,2),:); 

% V_coords is the coordinates of l1 and l2 intersection point
V_coords = [inter_lines_sortedY_asc(end, 1) inter_lines_sortedY_asc(end, 2) 1];
hold on;
scatter(V_coords(1),V_coords(2), 100,'ko', 'filled');


%% Selecting 4 points on C1. 
%  We will afterwards find their corresponding points on C2 to construct 2
%  pairs of parallel lines and thus 2 vanishing points. Then, by simply
%  connecting these two points, we can draw the vanishing line.

% point 1 -> A
% point 2 -> B
% point 3 -> C
% point 4 -> D

[U_x, U_y] = getpts;

% Drawing A and B in green and C and D in red
for i = 1:4
    if i < 3
        hold on;
        scatter(U_x(i),U_y(i), 50,'go', 'filled');
    else
        hold on;
        scatter(U_x(i),U_y(i), 50,'ro', 'filled');
    end
end

% Drawing lines AD and BC
% U_x(1) U_y(1) -> A
% U_x(2) U_y(2) -> B
% U_x(3) U_y(3) -> C
% U_x(4) U_y(4) -> D

A_and_D_coords = [U_x(1) U_y(1) 1; U_x(4) U_y(4) 1];
AD_coeffs  = null(A_and_D_coords);
plotLine(AD_coeffs, [0 maxw], 'r-', 1);

B_and_C_coords = [U_x(2) U_y(2) 1; U_x(3) U_y(3) 1];
BC_coeffs  = null(B_and_C_coords);
plotLine(BC_coeffs, [0 maxw], 'r-', 1);

%%
% In order to find A, B, C and D peers on C2 we draw a line from them to V
% (intersectino of l1 and l2) and find their intersection with C2.

color = 'b--'; width = 1;
for i = 1 : length(U_y)
    line_UV{i} = [U_x(i) U_y(i) 1;V_coords(1) V_coords(2) 1];
    UV_coeffs{i} = null(line_UV{i}(:,:));
    plotLine(UV_coeffs{i}(:,:),[0 maxw], color , width);
end


%% Finding A', B', C' and D' by intersecting their AV, BV, CV and DV with the conic C2
% each line will have 2 intersecting points with C2 and we need to choose
% one of them based on the line beginning. E.g. if the line begins from the
% upper edge of C1, then the intersecting point which is on the upper edge
% of C2 have to be picked.

for i  = 1 : 2
    intersection = intersectLineWithConic(UV_coeffs{i}(:,:), conicCoeffFromMatrix(C2));
    hold on;
    [val,idx] = max(intersection(:,2)); % choosing the bigger y coordinate
    D_x(i) = intersection(idx,1);
    D_y(i) = intersection(idx,2);
    scatter(D_x(i),D_y(i), 50,'go', 'filled');
end

for i = 3 : 4
    intersection = intersectLineWithConic(UV_coeffs{i}(:,:), conicCoeffFromMatrix(C2));
    hold on;
    [val,idx] = min(intersection(:,2)); % choosing the smaller y coordinate
    D_x(i) = intersection(idx,1);
    D_y(i) = intersection(idx,2);
    scatter(D_x(i),D_y(i), 50,'ro', 'filled');
end

% renaming variables for ease of use
A_prime = [D_x(1) D_y(1) 1];
B_prime = [D_x(2) D_y(2) 1];
C_prime = [D_x(3) D_y(3) 1];
D_prime = [D_x(4) D_y(4) 1];

%% Draw lines A'D' and B'C'

Ap_and_Dp_coords = [A_prime; D_prime];
ApDp_coeffs  = null(Ap_and_Dp_coords);
plotLine(ApDp_coeffs, [0 maxw], 'r-', 1);

Bp_and_Cp_coords = [B_prime; C_prime];
BpCp_coeffs  = null(Bp_and_Cp_coords);
plotLine(BpCp_coeffs, [0 maxw], 'r-', 1);

%%

%% Find intersection of AD with A'D' and BC with B'C'

V1 = intersectlines(ApDp_coeffs, AD_coeffs);
hold on;
scatter(V1(1), V1(2), 50,'wo', 'filled')

V2 = intersectlines(BpCp_coeffs, BC_coeffs);
hold on;
scatter(V2(1), V2(2), 50,'wo', 'filled')

%%
%% Plotting the Horizon Line

V1_and_V2_coords = [V1 1; V2 1];
V1V2_coeffs  = null(V1_and_V2_coords); % Coefficients of the horizon (vanishing) line
plotLine(V1V2_coeffs, [0 maxw], 'g-', 3);

%%
% Theory Question 2
%% Finding the central point of conic C1
% P1 and P2 are tangent points of l1 and l2 with C1 respectively
P1 = [inter_lines_sortedY_asc(1,1),inter_lines_sortedY_asc(1,2) 1];
P2 = [inter_lines_sortedY_asc(2,1),inter_lines_sortedY_asc(2,2) 1];

% P_c is the center of C1
P_c= [(P1(1)+P2(1))/2 (P1(2)+P2(2))/2 1];
%%
%% Drawing image of the cone axis from V to P_c

Pc_and_V_coords = [P_c; V_coords];
Pc_V_coeffs  = null(Pc_and_V_coords);
plotLine(Pc_V_coeffs, [0 maxw], 'm-', 3);

%%
%% Theory 3: Finding the Calibration Matrix

% three vanishing points with orth directions
h1 = intersectlines(minor_line_coeffs_c1, minor_line_coeffs_c2)';
h2 = intersectlines(major_line_coeffs_c1, major_line_coeffs_c2)';
% vanishing point orthogonal to the face (planes) containing C1 and C2
% Pc_V_coeffs is the coefficients of the cone axis line
Van_pnt_orth = intersectlines(Pc_V_coeffs,line_IJ)'; 

syms ffx, syms u0, syms v0;
% Since it is a natural camera, then Fx = Fy, and we know that skew = 0.
% Therefore the matrix K will look like this:
K = [ffx, 0, u0; ...
     0, ffx, v0; ...
     0, 0, 1];
w_dual = K*K.';
w = inv(w_dual);
eqn1 = [h1; 1].' * w * [h2; 1] == 0 ;
eqn2 = [h1; 1].' * w * [Van_pnt_orth; 1] == 0 ;
eqn3 = [h2; 1].' * w * [Van_pnt_orth; 1] == 0 ;
eqns = [eqn1, eqn2, eqn3];
res = solve(eqns);
ffx = real(double(res.ffx)); ffx = ffx(ffx >= 0); ffx = ffx(1);
fy = ffx;
u0 = real(double(res.u0)); u0 = u0(1);
v0 = real(double(res.v0)); v0 = v0(1);
clear K, clear eqs, clear res;

% Printing the normalized matrix K
K = [ffx, 0, u0; ...
     0, fy, v0; ...
     0, 0, 1]



%% Theory 4:
slope_of_horizon = Pc_V_coeffs(1,1)/Pc_V_coeffs(2,1);
deg = rad2deg(atan(slope_of_horizon))
%%

%% Theory 5:
imDCCP = II*JJ' + JJ*II';
imDCCP = imDCCP./norm(imDCCP);
[U,D,V] = svd(imDCCP);
D(3,3) = 1;
A = U*sqrt(D);
H = inv(A); % rectifying homography


% Finding the coefficients of the line l1.
% P1 is the tangent points of l1 with C1 and V is the cone vertex.

P1_V = [P1; V_coords];
l1 = null(P1_V);
plotLine(l1, [0 maxw], 'b-', 3);

% Finding the cone axis and the line l1 coefficients wrt the camera reference.
cone_axis_prime = K.' * Pc_V_coeffs;
l1_prime = K.' * l1;
cone_axis_prime = cone_axis_prime';
l1_prime = l1_prime';
% finding the angle between l1 and cone axis.
angle = atan2(abs(det([l1_prime(1:2); cone_axis_prime(1:2)])), dot(l1_prime(1:2), cone_axis_prime(1:2)));
degrees = angle*180/pi
