function I_out = detect_edge_sobel(I)
[~,threshold] = edge(I,'sobel');
fudgeFactor = 0.6;
I_out = edge(I,'sobel',threshold * fudgeFactor);
end