function [r] = intersectlines(coeffs1,coeffs2)
    syms x, syms y;

    a1 = coeffs1(1);
    b1 = coeffs1(2);
    c1 = coeffs1(3);
    a2 = coeffs2(1);
    b2 = coeffs2(2);
    c2 = coeffs2(3);

    eqn1 = a1*x +b1*y + c1;
    eqn2 = a2*x+ b2*y + c2;

    eqns = [eqn1, eqn2];
    sol = solve(eqns);

    r = [double(sol.x), double(sol.y)];
end